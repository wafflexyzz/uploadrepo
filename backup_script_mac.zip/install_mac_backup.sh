#!/bin/bash

# Installer script to set up daily backup system for the 'mac' user
# Run this script as the current user (newadmin) to install for the mac user

MAC_USER="mac"
MAC_HOME="/Users/$MAC_USER"
BACKUP_SCRIPT="$MAC_HOME/daily_backup.sh"
LAUNCH_AGENT_DIR="$MAC_HOME/Library/LaunchAgents"
LAUNCH_AGENT="$LAUNCH_AGENT_DIR/com.user.dailybackup.plist"
SETUP_SCRIPT="$MAC_HOME/setup_backup.sh"

echo "Installing daily backup system for user '$MAC_USER'..."
echo

# Check if mac user exists
if ! id "$MAC_USER" &>/dev/null; then
    echo "❌ User '$MAC_USER' does not exist!"
    echo "Please create the user first or modify the MAC_USER variable in this script."
    exit 1
fi

# Check if we can access the mac user's home directory
if [[ ! -d "$MAC_HOME" ]]; then
    echo "❌ Cannot access $MAC_HOME"
    echo "Please ensure the 'mac' user's home directory exists and is accessible."
    exit 1
fi

echo "✅ User '$MAC_USER' found with home directory: $MAC_HOME"
echo

# Create the backup script
echo "📝 Creating backup script..."
cat > "$BACKUP_SCRIPT" << 'EOF'
#!/bin/bash

# Daily Backup Script for /Users/mac to iCloud Drive
# Uses hard links like Time Machine to save space

set -e  # Exit on any error

# Configuration
SOURCE_DIR="/Users/mac"
BACKUP_BASE="/Users/mac/Library/Mobile Documents/com~apple~CloudDocs/Backups"
DATE=$(date '+%Y-%m-%d_%H-%M-%S')
CURRENT_BACKUP="$BACKUP_BASE/$DATE"
LATEST_LINK="$BACKUP_BASE/Latest"
LOG_FILE="$BACKUP_BASE/backup.log"

# Function to log messages
log_message() {
    echo "$(date '+%Y-%m-%d %H:%M:%S'): $1" | tee -a "$LOG_FILE"
}

# Check if source directory exists
if [[ ! -d "$SOURCE_DIR" ]]; then
    log_message "ERROR: Source directory $SOURCE_DIR does not exist"
    exit 1
fi

# Create backup base directory if it doesn't exist
mkdir -p "$BACKUP_BASE"

# Start backup
log_message "Starting backup of $SOURCE_DIR to $CURRENT_BACKUP"

# Find the most recent backup for hard linking
LAST_BACKUP=""
if [[ -L "$LATEST_LINK" && -d "$(readlink "$LATEST_LINK")" ]]; then
    LAST_BACKUP="$(readlink "$LATEST_LINK")"
    log_message "Using previous backup for hard linking: $LAST_BACKUP"
fi

# Perform the backup using rsync with hard links
RSYNC_OPTS=(
    -av                    # archive mode, verbose
    --delete              # delete files that no longer exist in source
    --delete-excluded     # delete excluded files from destination
    --exclude='.DS_Store' # exclude macOS metadata files
    --exclude='._*'       # exclude macOS resource forks
    --exclude='.Trash'    # exclude trash
    --exclude='.cache'    # exclude cache directories
    --exclude='Cache'     # exclude cache directories
    --exclude='*.tmp'     # exclude temporary files
    --exclude='*.swp'     # exclude vim swap files
    --exclude='.localized' # exclude localized folder names
    --exclude='Library/Mobile Documents/com~apple~CloudDocs/Backups' # exclude the backup directory itself
)

# Add hard link option if we have a previous backup
if [[ -n "$LAST_BACKUP" ]]; then
    RSYNC_OPTS+=(--link-dest="$LAST_BACKUP")
fi

# Run rsync
if rsync "${RSYNC_OPTS[@]}" "$SOURCE_DIR/" "$CURRENT_BACKUP/"; then
    log_message "Backup completed successfully"
    
    # Update the 'Latest' symlink
    rm -f "$LATEST_LINK"
    ln -s "$CURRENT_BACKUP" "$LATEST_LINK"
    
    # Clean up old backups (keep last 30 days)
    log_message "Cleaning up old backups (keeping last 30 days)"
    find "$BACKUP_BASE" -maxdepth 1 -type d -name "20*" -mtime +30 -exec rm -rf {} \;
    
    # Calculate and log backup size
    BACKUP_SIZE=$(du -sh "$CURRENT_BACKUP" | cut -f1)
    TOTAL_SIZE=$(du -sh "$BACKUP_BASE" | cut -f1)
    log_message "Backup size: $BACKUP_SIZE, Total backup storage: $TOTAL_SIZE"
    
else
    log_message "ERROR: Backup failed"
    # Remove incomplete backup
    [[ -d "$CURRENT_BACKUP" ]] && rm -rf "$CURRENT_BACKUP"
    exit 1
fi

log_message "Backup process completed"

# Optional: Send notification (requires terminal-notifier: brew install terminal-notifier)
if command -v terminal-notifier >/dev/null 2>&1; then
    terminal-notifier -title "Backup Complete" -message "Daily backup of /Users/mac completed successfully" -sound default
fi
EOF

# Make backup script executable
chmod +x "$BACKUP_SCRIPT"
echo "✅ Created executable backup script: $BACKUP_SCRIPT"

# Create LaunchAgents directory
mkdir -p "$LAUNCH_AGENT_DIR"

# Create the launch agent plist
echo "📝 Creating launch agent..."
cat > "$LAUNCH_AGENT" << EOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>Label</key>
    <string>com.user.dailybackup</string>
    
    <key>ProgramArguments</key>
    <array>
        <string>/bin/bash</string>
        <string>$BACKUP_SCRIPT</string>
    </array>
    
    <key>StartCalendarInterval</key>
    <dict>
        <key>Hour</key>
        <integer>2</integer>
        <key>Minute</key>
        <integer>0</integer>
    </dict>
    
    <key>RunAtLoad</key>
    <false/>
    
    <key>StandardOutPath</key>
    <string>/Users/mac/Library/Mobile Documents/com~apple~CloudDocs/Backups/launchd.log</string>
    
    <key>StandardErrorPath</key>
    <string>/Users/mac/Library/Mobile Documents/com~apple~CloudDocs/Backups/launchd.log</string>
    
    <key>EnvironmentVariables</key>
    <dict>
        <key>PATH</key>
        <string>/usr/local/bin:/usr/bin:/bin</string>
    </dict>
</dict>
</plist>
EOF

echo "✅ Created launch agent: $LAUNCH_AGENT"

# Create the setup script for the mac user
echo "📝 Creating setup script for mac user..."
cat > "$SETUP_SCRIPT" << 'EOF'
#!/bin/bash

# Setup script for daily backup system (for mac user)

BACKUP_SCRIPT="/Users/mac/daily_backup.sh"
LAUNCH_AGENT="/Users/mac/Library/LaunchAgents/com.user.dailybackup.plist"
LABEL="com.user.dailybackup"

show_usage() {
    echo "Usage: $0 [install|uninstall|start|stop|status|test|logs]"
    echo ""
    echo "Commands:"
    echo "  install   - Install and start the daily backup service"
    echo "  uninstall - Stop and remove the daily backup service"
    echo "  start     - Start the backup service"
    echo "  stop      - Stop the backup service"
    echo "  status    - Show service status"
    echo "  test      - Run a test backup manually"
    echo "  logs      - Show recent backup logs"
}

install_backup() {
    echo "Installing daily backup service..."
    
    # Load the launch agent
    launchctl load "$LAUNCH_AGENT"
    
    if [[ $? -eq 0 ]]; then
        echo "✅ Daily backup service installed and started"
        echo "✅ Backups will run daily at 2:00 AM"
        echo "✅ Backups will be stored in: ~/Library/Mobile Documents/com~apple~CloudDocs/Backups"
    else
        echo "❌ Failed to install backup service"
        exit 1
    fi
}

uninstall_backup() {
    echo "Uninstalling daily backup service..."
    
    # Unload the launch agent
    launchctl unload "$LAUNCH_AGENT" 2>/dev/null
    
    echo "✅ Daily backup service stopped and uninstalled"
    echo "Note: Existing backups in iCloud Drive will remain untouched"
}

start_backup() {
    echo "Starting daily backup service..."
    launchctl load "$LAUNCH_AGENT"
    if [[ $? -eq 0 ]]; then
        echo "✅ Daily backup service started"
    else
        echo "❌ Failed to start backup service (may already be running)"
    fi
}

stop_backup() {
    echo "Stopping daily backup service..."
    launchctl unload "$LAUNCH_AGENT" 2>/dev/null
    echo "✅ Daily backup service stopped"
}

show_status() {
    echo "Backup Service Status:"
    if launchctl list | grep -q "$LABEL"; then
        echo "✅ Service is running"
        
        # Show last backup info
        BACKUP_DIR="/Users/mac/Library/Mobile Documents/com~apple~CloudDocs/Backups"
        if [[ -L "$BACKUP_DIR/Latest" ]]; then
            LATEST=$(readlink "$BACKUP_DIR/Latest")
            LATEST_NAME=$(basename "$LATEST")
            echo "✅ Last backup: $LATEST_NAME"
            
            if [[ -f "$BACKUP_DIR/backup.log" ]]; then
                LAST_LOG=$(tail -n 1 "$BACKUP_DIR/backup.log")
                echo "✅ Last log entry: $LAST_LOG"
            fi
        else
            echo "ℹ️ No backups found yet"
        fi
    else
        echo "❌ Service is not running"
    fi
}

test_backup() {
    echo "Running test backup..."
    echo "This may take a while depending on the size of /Users/mac"
    echo ""
    
    if [[ -x "$BACKUP_SCRIPT" ]]; then
        "$BACKUP_SCRIPT"
    else
        echo "❌ Backup script not found or not executable: $BACKUP_SCRIPT"
        exit 1
    fi
}

show_logs() {
    BACKUP_DIR="/Users/mac/Library/Mobile Documents/com~apple~CloudDocs/Backups"
    
    echo "Recent backup logs:"
    echo "=================="
    
    if [[ -f "$BACKUP_DIR/backup.log" ]]; then
        tail -n 20 "$BACKUP_DIR/backup.log"
    else
        echo "No backup logs found yet"
    fi
    
    echo ""
    echo "LaunchAgent logs:"
    echo "================="
    
    if [[ -f "$BACKUP_DIR/launchd.log" ]]; then
        tail -n 10 "$BACKUP_DIR/launchd.log"
    else
        echo "No launchd logs found yet"
    fi
}

# Main script logic
case "$1" in
    install)
        install_backup
        ;;
    uninstall)
        uninstall_backup
        ;;
    start)
        start_backup
        ;;
    stop)
        stop_backup
        ;;
    status)
        show_status
        ;;
    test)
        test_backup
        ;;
    logs)
        show_logs
        ;;
    *)
        show_usage
        exit 1
        ;;
esac
EOF

# Make setup script executable
chmod +x "$SETUP_SCRIPT"
echo "✅ Created setup script: $SETUP_SCRIPT"

# Set proper ownership for all files
echo "🔧 Setting proper ownership..."
chown -R "$MAC_USER:staff" "$BACKUP_SCRIPT" "$LAUNCH_AGENT_DIR" "$SETUP_SCRIPT" 2>/dev/null || {
    echo "⚠️  Could not set ownership. The mac user will need to run the scripts manually."
    echo "   This is normal if you don't have admin privileges."
}

echo
echo "🎉 Installation complete!"
echo
echo "📋 Next steps for the 'mac' user:"
echo "   1. Switch to the mac user account"
echo "   2. Run: ~/setup_backup.sh install"
echo "   3. Or test first with: ~/setup_backup.sh test"
echo
echo "📁 Files created:"
echo "   • $BACKUP_SCRIPT"
echo "   • $LAUNCH_AGENT"
echo "   • $SETUP_SCRIPT"
echo
echo "💾 Backups will be stored in:"
echo "   ~/Library/Mobile Documents/com~apple~CloudDocs/Backups/"
echo "   (This is the mac user's iCloud Drive)"
echo

