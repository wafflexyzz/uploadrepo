#!/bin/bash

# Setup script for daily backup system

BACKUP_SCRIPT="/Users/newadmin/daily_backup.sh"
LAUNCH_AGENT="/Users/newadmin/Library/LaunchAgents/com.user.dailybackup.plist"
LABEL="com.user.dailybackup"

show_usage() {
    echo "Usage: $0 [install|uninstall|start|stop|status|test|logs]"
    echo ""
    echo "Commands:"
    echo "  install   - Install and start the daily backup service"
    echo "  uninstall - Stop and remove the daily backup service"
    echo "  start     - Start the backup service"
    echo "  stop      - Stop the backup service"
    echo "  status    - Show service status"
    echo "  test      - Run a test backup manually"
    echo "  logs      - Show recent backup logs"
}

install_backup() {
    echo "Installing daily backup service..."
    
    # Check if /Users/mac exists
    if [[ ! -d "/Users/mac" ]]; then
        echo "WARNING: /Users/mac directory does not exist."
        echo "Please create it or modify the SOURCE_DIR in $BACKUP_SCRIPT"
        read -p "Continue anyway? (y/N): " -n 1 -r
        echo
        if [[ ! $REPLY =~ ^[Yy]$ ]]; then
            exit 1
        fi
    fi
    
    # Load the launch agent
    launchctl load "$LAUNCH_AGENT"
    
    if [[ $? -eq 0 ]]; then
        echo "✓ Daily backup service installed and started"
        echo "✓ Backups will run daily at 2:00 AM"
        echo "✓ Backups will be stored in: ~/Library/Mobile Documents/com~apple~CloudDocs/Backups"
    else
        echo "✗ Failed to install backup service"
        exit 1
    fi
}

uninstall_backup() {
    echo "Uninstalling daily backup service..."
    
    # Unload the launch agent
    launchctl unload "$LAUNCH_AGENT" 2>/dev/null
    
    echo "✓ Daily backup service stopped and uninstalled"
    echo "Note: Existing backups in iCloud Drive will remain untouched"
}

start_backup() {
    echo "Starting daily backup service..."
    launchctl load "$LAUNCH_AGENT"
    if [[ $? -eq 0 ]]; then
        echo "✓ Daily backup service started"
    else
        echo "✗ Failed to start backup service (may already be running)"
    fi
}

stop_backup() {
    echo "Stopping daily backup service..."
    launchctl unload "$LAUNCH_AGENT" 2>/dev/null
    echo "✓ Daily backup service stopped"
}

show_status() {
    echo "Backup Service Status:"
    if launchctl list | grep -q "$LABEL"; then
        echo "✓ Service is running"
        
        # Show last backup info
        BACKUP_DIR="$HOME/Library/Mobile Documents/com~apple~CloudDocs/Backups"
        if [[ -L "$BACKUP_DIR/Latest" ]]; then
            LATEST=$(readlink "$BACKUP_DIR/Latest")
            LATEST_NAME=$(basename "$LATEST")
            echo "✓ Last backup: $LATEST_NAME"
            
            if [[ -f "$BACKUP_DIR/backup.log" ]]; then
                LAST_LOG=$(tail -n 1 "$BACKUP_DIR/backup.log")
                echo "✓ Last log entry: $LAST_LOG"
            fi
        else
            echo "ℹ No backups found yet"
        fi
    else
        echo "✗ Service is not running"
    fi
}

test_backup() {
    echo "Running test backup..."
    echo "This may take a while depending on the size of /Users/mac"
    echo ""
    
    if [[ -x "$BACKUP_SCRIPT" ]]; then
        "$BACKUP_SCRIPT"
    else
        echo "✗ Backup script not found or not executable: $BACKUP_SCRIPT"
        exit 1
    fi
}

show_logs() {
    BACKUP_DIR="$HOME/Library/Mobile Documents/com~apple~CloudDocs/Backups"
    
    echo "Recent backup logs:"
    echo "=================="
    
    if [[ -f "$BACKUP_DIR/backup.log" ]]; then
        tail -n 20 "$BACKUP_DIR/backup.log"
    else
        echo "No backup logs found yet"
    fi
    
    echo ""
    echo "LaunchAgent logs:"
    echo "================="
    
    if [[ -f "$BACKUP_DIR/launchd.log" ]]; then
        tail -n 10 "$BACKUP_DIR/launchd.log"
    else
        echo "No launchd logs found yet"
    fi
}

# Main script logic
case "$1" in
    install)
        install_backup
        ;;
    uninstall)
        uninstall_backup
        ;;
    start)
        start_backup
        ;;
    stop)
        stop_backup
        ;;
    status)
        show_status
        ;;
    test)
        test_backup
        ;;
    logs)
        show_logs
        ;;
    *)
        show_usage
        exit 1
        ;;
esac

