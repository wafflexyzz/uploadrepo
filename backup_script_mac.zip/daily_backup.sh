#!/bin/bash

# Daily Backup Script for /Users/mac to iCloud Drive
# Uses hard links like Time Machine to save space

set -e  # Exit on any error

# Configuration
SOURCE_DIR="/Users/mac"
BACKUP_BASE="/Users/mac/Library/Mobile Documents/com~apple~CloudDocs/Backups"
DATE=$(date '+%Y-%m-%d_%H-%M-%S')
CURRENT_BACKUP="$BACKUP_BASE/$DATE"
LATEST_LINK="$BACKUP_BASE/Latest"
LOG_FILE="$BACKUP_BASE/backup.log"

# Function to log messages
log_message() {
    echo "$(date '+%Y-%m-%d %H:%M:%S'): $1" | tee -a "$LOG_FILE"
}

# Check if source directory exists
if [[ ! -d "$SOURCE_DIR" ]]; then
    log_message "ERROR: Source directory $SOURCE_DIR does not exist"
    exit 1
fi

# Create backup base directory if it doesn't exist
mkdir -p "$BACKUP_BASE"

# Start backup
log_message "Starting backup of $SOURCE_DIR to $CURRENT_BACKUP"

# Find the most recent backup for hard linking
LAST_BACKUP=""
if [[ -L "$LATEST_LINK" && -d "$(readlink "$LATEST_LINK")" ]]; then
    LAST_BACKUP="$(readlink "$LATEST_LINK")"
    log_message "Using previous backup for hard linking: $LAST_BACKUP"
fi

# Perform the backup using rsync with hard links
RSYNC_OPTS=(
    -av                    # archive mode, verbose
    --delete              # delete files that no longer exist in source
    --delete-excluded     # delete excluded files from destination
    --exclude='.DS_Store' # exclude macOS metadata files
    --exclude='._*'       # exclude macOS resource forks
    --exclude='.Trash'    # exclude trash
    --exclude='.cache'    # exclude cache directories
    --exclude='Cache'     # exclude cache directories
    --exclude='*.tmp'     # exclude temporary files
    --exclude='*.swp'     # exclude vim swap files
    --exclude='.localized' # exclude localized folder names
)

# Add hard link option if we have a previous backup
if [[ -n "$LAST_BACKUP" ]]; then
    RSYNC_OPTS+=(--link-dest="$LAST_BACKUP")
fi

# Run rsync
if rsync "${RSYNC_OPTS[@]}" "$SOURCE_DIR/" "$CURRENT_BACKUP/"; then
    log_message "Backup completed successfully"
    
    # Update the 'Latest' symlink
    rm -f "$LATEST_LINK"
    ln -s "$CURRENT_BACKUP" "$LATEST_LINK"
    
    # Clean up old backups (keep last 30 days)
    log_message "Cleaning up old backups (keeping last 30 days)"
    find "$BACKUP_BASE" -maxdepth 1 -type d -name "20*" -mtime +30 -exec rm -rf {} \;
    
    # Calculate and log backup size
    BACKUP_SIZE=$(du -sh "$CURRENT_BACKUP" | cut -f1)
    TOTAL_SIZE=$(du -sh "$BACKUP_BASE" | cut -f1)
    log_message "Backup size: $BACKUP_SIZE, Total backup storage: $TOTAL_SIZE"
    
else
    log_message "ERROR: Backup failed"
    # Remove incomplete backup
    [[ -d "$CURRENT_BACKUP" ]] && rm -rf "$CURRENT_BACKUP"
    exit 1
fi

log_message "Backup process completed"

# Optional: Send notification (requires terminal-notifier: brew install terminal-notifier)
if command -v terminal-notifier >/dev/null 2>&1; then
    terminal-notifier -title "Backup Complete" -message "Daily backup of /Users/mac completed successfully" -sound default
fi

