# Daily Backup System for Mac User

This system creates Time Machine-style backups of the `/Users/mac` folder to iCloud Drive.

## Installation

### Step 1: Install the backup system
Run the installer script as the current user (newadmin):
```bash
./install_mac_backup.sh
```

### Step 2: Switch to the mac user and activate
1. Switch to the mac user account (via Fast User Switching or `su mac`)
2. Open Terminal as the mac user
3. Run one of these commands:

```bash
# Test the backup first (recommended)
~/setup_backup.sh test

# Or install and start the daily service immediately
~/setup_backup.sh install
```

## How It Works

✅ **Time Machine Style**: Uses hard links to save space - only changed files are stored
✅ **Daily Automatic**: Runs every day at 2:00 AM
✅ **iCloud Storage**: Backups stored in mac user's iCloud Drive
✅ **Smart Exclusions**: Skips cache files, temporary files, and other unnecessary data
✅ **Auto Cleanup**: Keeps 30 days of backups

## Management Commands (for mac user)

```bash
# Check if backup service is running
~/setup_backup.sh status

# Start the daily backup service
~/setup_backup.sh start

# Stop the daily backup service
~/setup_backup.sh stop

# Run a manual backup test
~/setup_backup.sh test

# View recent backup logs
~/setup_backup.sh logs

# Completely remove the backup service
~/setup_backup.sh uninstall
```

## Backup Location

Backups are stored in:
```
~/Library/Mobile Documents/com~apple~CloudDocs/Backups/
```

Each backup is timestamped (e.g., `2024-06-14_14-30-15`) and a `Latest` symlink always points to the most recent backup.

## What Gets Backed Up

✅ **Included**: All files and folders in `/Users/mac/`
❌ **Excluded**: 
- `.DS_Store` files
- Cache directories
- Temporary files
- Trash folders
- The backup directory itself

## File Structure

```
/Users/mac/
├── daily_backup.sh          # Main backup script
├── setup_backup.sh          # Management script
└── Library/LaunchAgents/
    └── com.user.dailybackup.plist  # Auto-start configuration
```

## Troubleshooting

### Backup not running automatically?
1. Check if service is loaded: `~/setup_backup.sh status`
2. Check logs: `~/setup_backup.sh logs`
3. Restart service: `~/setup_backup.sh stop && ~/setup_backup.sh start`

### iCloud Drive not syncing?
- Make sure iCloud Drive is enabled for the mac user
- Check iCloud storage space
- Verify the path exists: `ls ~/Library/Mobile\ Documents/com~apple~CloudDocs/`

### Permission issues?
- Make sure all scripts are executable
- Ensure the mac user owns all the files
- Check that `/Users/mac` is readable

## Notes

- The backup system is designed to be lightweight and efficient
- First backup will take longer as it copies all files
- Subsequent backups are much faster due to hard linking
- Backups continue to work even if the mac user is not logged in
- The system automatically handles iCloud Drive synchronization

